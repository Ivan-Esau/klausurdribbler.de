package KlausurVorbereitung;

public interface PokemonInterface
{
    /*
    Für die Teilnahme an den Trainingsduellen soll sichergestellt werden, dass jedes Pokémon grundlegende Kommandos erlernt hat:
    - getName()
    - getKraft()
    - attacke()
     */

    //Rückgabe Typen einfach variabel anpassen wenn sonst nichts gegeben ist.

     String getName();
     int getKraft();
     void attack(PokemonInterface gegner);
     void setKraft(int kraft);
     int getHealth();
     int setHealth(int aktuelleGesundheit);


}
