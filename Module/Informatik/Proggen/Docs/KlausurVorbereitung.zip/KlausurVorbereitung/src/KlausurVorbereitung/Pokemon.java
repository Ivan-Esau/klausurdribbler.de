package KlausurVorbereitung;


public class Pokemon extends Gegner implements PokemonInterface
{
    public Pokemon(String name)
    {
        super(name);
    }
}
