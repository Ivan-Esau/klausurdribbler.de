package KlausurVorbereitung;

public interface TrainerInterface
{
    /*
    Die Trainer sollten für die Trainingsduelle grundlegende Kommandos kennen, um die eingesetzten Pokémon unter Kontrolle zu haben:
    - getTrainerName()
    - pokémonEinsetzen()
    - aufgeben()

        Für spätere Wettkämpfe:
        - pokémonAbgeben()

    //Rückgabe Typen einfach variabel anpassen, wenn sonst nichts gegeben ist.
     */
     String getTrainerName();
     //PokemonEinsetzen
     PokemonInterface pokemonEinsetzen(String auswahl);
     //PokemonAbgeben
     void pokemonAbgeben(PokemonInterface neuesPokemon);
     void pokemonHinzu(PokemonInterface neuesPokemon);
     void aufgeben();
}
