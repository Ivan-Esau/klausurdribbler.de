package KlausurVorbereitung;

public class Arena
{
    private TrainerInterface trainer1;
    private TrainerInterface trainer2;

    public Arena(TrainerInterface trainer1, TrainerInterface trainer2)
    {
        this.trainer1 = trainer1;
        this.trainer2 = trainer2;
    }

    public void training(String trainer1pokemon, String trainer2pokemon)
    {
        //Kampf startet
        System.out.println("Der Kampf " + trainer1.getTrainerName() + " Vs " + trainer2.getTrainerName() + " startet!");

        //Pokemon werden eingesetzt
        PokemonInterface pokemon1 = trainer1.pokemonEinsetzen(trainer1pokemon);
        PokemonInterface pokemon2 = trainer2.pokemonEinsetzen(trainer2pokemon);

        while(!(pokemon1.getHealth() <= 20 || pokemon2.getHealth() <= 20))
        {
            System.out.println("Die Pokemon Kämpfen!!!");
            pokemon1.attack(pokemon2);
        }

        if(pokemon1.getHealth() <= 20)
        {
            trainer1.aufgeben();
            System.out.println("Die Kraft von " + pokemon2.getName() + " Steigt um: 5 Punkte");
            pokemon2.setKraft(pokemon2.getKraft() + 5);
        }

        else if(pokemon2.getHealth() <= 20)
        {
            trainer2.aufgeben();
            System.out.println("Die Kraft von " + pokemon1.getName() + " Steigt um: 5 Punkte");
            pokemon1.setKraft(pokemon1.getKraft() + 5);

        }
    }
}
