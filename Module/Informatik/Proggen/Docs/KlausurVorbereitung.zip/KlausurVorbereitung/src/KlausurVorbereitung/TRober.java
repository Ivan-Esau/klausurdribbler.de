package KlausurVorbereitung;

public class TRober extends Gegner
{
    public TRober(String name, int hitpoints) {
        super(name);
    }
    public void speziellerAngriff()
    {

    }
}
