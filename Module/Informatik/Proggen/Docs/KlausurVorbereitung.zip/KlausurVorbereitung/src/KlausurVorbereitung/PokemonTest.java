package KlausurVorbereitung;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class PokemonTest
{
    @Test
    void getNameTest()
    {
        PokemonInterface pikachu = new Pokemon("pikachu");
        Assertions.assertEquals("pikachu",pikachu.getName());
    }

    @Test
    void getKraftTest()
    {
        PokemonInterface pikachu = new Pokemon("pikachu");

        boolean gueltig = (pikachu.getKraft() >= 40 && pikachu.getKraft() <=80);
        Assertions.assertTrue(gueltig);
    }

    @Test
    void attackTest()
    {
        PokemonInterface pikachu = new Pokemon("pikachu");
        boolean gueltig = (pikachu.getKraft() >= 40 && pikachu.getKraft() <=80);
        Assertions.assertTrue(gueltig);
    }

    @Test
    void getHealthTest()
    {
        PokemonInterface pikachu = new Pokemon("pikachu");
        Assertions.assertEquals(100,pikachu.getHealth());
    }
}