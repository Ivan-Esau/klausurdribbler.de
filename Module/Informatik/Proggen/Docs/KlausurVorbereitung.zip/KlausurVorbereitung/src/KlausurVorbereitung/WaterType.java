package KlausurVorbereitung;

public interface WaterType {
}
