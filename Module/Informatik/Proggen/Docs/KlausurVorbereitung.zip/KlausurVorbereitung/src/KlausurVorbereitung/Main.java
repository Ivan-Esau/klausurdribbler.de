package KlausurVorbereitung;

public class Main
{
    public static void main(String[] args)
    {
        //Objekterstellung für Pokemon-Liste
        PokemonInterface pikachu = new Pokemon("Pikachu");
        PokemonInterface glumanda = new Pokemon("Glumanda");

        PokemonInterface schiggy = new Pokemon("Schiggy");
        PokemonInterface bisasam = new Pokemon("Bisasam");

        //Trainer erstellen
        TrainerInterface ivan = new Trainer("Ivan");
        TrainerInterface karim = new Trainer("Karim");

        //Pokemon den Trainern zuweisen
        ivan.pokemonHinzu(pikachu);
        ivan.pokemonHinzu(glumanda);

        karim.pokemonHinzu(schiggy);
        karim.pokemonHinzu(bisasam);
        //---------------------Arena----------------------------
        //Trainings Kampf
        Arena kampf1 = new Arena(ivan, karim);
        kampf1.training(glumanda.getName(), bisasam.getName());
    }
}