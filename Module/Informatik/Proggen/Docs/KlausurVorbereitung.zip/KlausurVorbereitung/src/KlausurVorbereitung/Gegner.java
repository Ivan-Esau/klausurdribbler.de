package KlausurVorbereitung;

public abstract class Gegner {
    private String name;
    private int kraft;
    private int health;

    public Gegner(String name)
    {

        // Überprüfe, ob der Name null ist oder die Länge 0 hat
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Ungültiger Name für das Pokemon");
        }
        this.name = name;

        //Die Kraft sollte eine zufällige Zahl zwischen 40 und 80 sein.
        this.kraft = (int) (Math.random() * 41)+40;

        //Gesundheitswert (100 zu Beginn jedes Trainings)
        this.health = 100;
    }

    public String getName()
    {
        return name;
    }

    //getKraft

    public int getKraft()
    {
        return kraft;
    }

    //attacke

    public void attack(PokemonInterface gegner)
    {
        int damageMy = (int) (Math.random()) + this.kraft;
        int damageGegner = (int) (Math.random()) + gegner.getKraft();
        int aktuelleGesundheit = gegner.getHealth();

        if(this.kraft > gegner.getKraft())
        {
            gegner.setHealth(aktuelleGesundheit - damageMy);
            System.out.println(gegner.getName() + " Hat schaden erlitten! HP: " + gegner.getHealth() );
        }
        else if(this.kraft < gegner.getKraft())
        {
            this.setHealth(this.getHealth() - damageGegner);
            System.out.println(this.name + " Hat schaden erlitten! HP: " + this.health );
        }
        else
        {
            gegner.setHealth(aktuelleGesundheit - damageMy);
            this.setHealth(this.getHealth() - damageGegner);
        }

    }

    public int setHealth(int health)
    {
        return this.health = health;
    }

    public void setKraft(int kraft)
    {
        this.kraft = kraft;
    }

    //Nicht im Interface enthalten
    public int getHealth()
    {
        return health;
    }

    @Override
    public String toString() {
        return "name= " + name + '\'' + ", Stength =" + kraft + ", HP =" + health;
    }

}

