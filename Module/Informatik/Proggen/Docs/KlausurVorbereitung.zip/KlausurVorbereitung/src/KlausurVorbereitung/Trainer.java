package KlausurVorbereitung;

import java.util.HashSet;
import java.util.Set;

public class Trainer implements TrainerInterface
{
    /*
    Klasse Trainer – Jeder Trainer soll über einen Namen und eine Pokémon-Sammlung verfügen.
     */
    //Attribute
    private String name;
    //Die Sammlung soll flexibel erweiterbar und reduzierbar sein, allerdings soll ein Pokémon jeweils nur einmal ein eine Sammlung aufgenommen werden können.
    private Set<Pokemon> pokemonSammlung = new HashSet<>();
    //private set<Pokemon>;

    //Konstruktor
    public Trainer(String name)
    {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Ungültiger Name für den Trainer");
        }
        this.name = name;
        this.pokemonSammlung = new HashSet<>();
    }

    //getTrainieren
    @Override
    public String getTrainerName()
    {
        return name;
    }

    //PokemonEinsetzen
    @Override
    public PokemonInterface pokemonEinsetzen(String auswahl)
    {
        if (!pokemonSammlung.isEmpty())
        {
            PokemonInterface ausgewaehltesPokemon = null;

            for (PokemonInterface pokemon : pokemonSammlung)
            {
                if (pokemon.getName().equalsIgnoreCase(auswahl))
                {
                    ausgewaehltesPokemon = pokemon;
                    System.out.println(name + " setzt " + ausgewaehltesPokemon.getName() + " ein!");
                    System.out.println(ausgewaehltesPokemon);
                    return ausgewaehltesPokemon;
                }
            }

            if (ausgewaehltesPokemon != null)
            {
                System.out.println(name + " setzt " + ausgewaehltesPokemon.getName() + " ein!");
                // Hier können Sie weitere Aktionen für das ausgewählte Pokémon durchführen
            }
            else
            {
                // Wenn das ausgewählte Pokémon nicht gefunden wurde, wähle das erste Pokémon aus der Liste
                PokemonInterface erstesPokemon = pokemonSammlung.iterator().next();
                System.out.println(name + " setzt " + erstesPokemon.getName() + " ein!");
                return erstesPokemon;
                // Hier können Sie weitere Aktionen für das erste Pokémon durchführen
            }
        }
        else
        {
            System.out.println(name + " hat keine Pokémon in der Sammlung!");
            System.out.println("Ersatz Pokemon!");
            PokemonInterface pokemon = new Pokemon("Pikachu");
            return pokemon;
        }
        System.out.println("Ersatz Pokemon!");
        PokemonInterface pokemon = new Pokemon("Pikachu");
        return pokemon;
    }

    //PokemonAbgeben
    @Override
    public void pokemonAbgeben(PokemonInterface neuesPokemon)
    {
        if (pokemonSammlung.contains(neuesPokemon)) {
            pokemonSammlung.remove(neuesPokemon);
            System.out.println(name + " hat " + neuesPokemon.getName() + " entfernt!");
        }
        else
        {
            System.out.println(name + " hat kein " + neuesPokemon.getName() + " in der Sammlung!");
        }
    }

    @Override
    public void pokemonHinzu(PokemonInterface neuesPokemon)
    {
        if (!pokemonSammlung.contains(neuesPokemon))
        {
            pokemonSammlung.add((Pokemon) neuesPokemon);
            System.out.println(name + " hat " + neuesPokemon.getName() + " hinzugefügt!");
        }
        else
        {
            System.out.println(name + " hat bereits " + neuesPokemon.getName() + " in der Sammlung!");
        }
    }

    //aufgeben
    @Override
    public void aufgeben()
    {
        System.out.println(this.name + " gibt auf!");
    }

    @Override
    public String toString() {
        return "Trainer {" + "name='" + name + '\'' + ", pokemonSammlung=" + pokemonSammlung + '}';
    }
}
