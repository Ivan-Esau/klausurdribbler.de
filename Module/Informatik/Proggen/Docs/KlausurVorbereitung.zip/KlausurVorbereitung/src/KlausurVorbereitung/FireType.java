package KlausurVorbereitung;

public interface FireType {
}
