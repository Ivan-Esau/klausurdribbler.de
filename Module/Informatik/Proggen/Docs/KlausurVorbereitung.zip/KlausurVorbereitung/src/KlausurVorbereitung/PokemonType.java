package KlausurVorbereitung;

public class PokemonType extends Pokemon implements FireType, WaterType
{

    public PokemonType(String name)
    {
        super(name);
    }
}
